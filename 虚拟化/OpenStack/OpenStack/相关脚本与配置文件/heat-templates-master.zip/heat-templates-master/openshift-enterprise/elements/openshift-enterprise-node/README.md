This element installs packages required by a typical OpenShift Enterprise node.

The objective of including these packages on the instance is to speed the boot time of a node.
