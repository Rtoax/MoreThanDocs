This element adds the following yum repositories which are known to work together:

- OpenShift Origin Release 1
- OpenShift Origin dependencies
- Jenkins
- PuppetLabs Products