==============
Heat Templates
==============

Heat is a service to orchestrate multiple composite cloud applications using
templates

This repository provides:

* Example templates which demonstrate core Heat functionality
* Related image-building templates
* Template-related scripts and conversion tools
